package Game;

public interface Runnable extends Participant{
    boolean run(int length);
}
