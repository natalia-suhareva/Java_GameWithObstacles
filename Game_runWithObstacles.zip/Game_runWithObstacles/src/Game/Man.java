package Game;

public class Man implements Jumpable, Runnable {
    private final String name;
    private final int maxRun;
    private final int maxJump;
    private boolean isStopped = false;

    Man(String name, int maxRun, int maxJump) {
        this.name = name;
        this.maxRun = maxRun;
        this.maxJump = maxJump;
    }

    @Override
    public boolean jump(int height) {
        if (height <= maxJump) {
            System.out.println("Человек " + name + " перепрыгнул через препятствие  высотой: " + height);
            return true;
        } else {
            System.out.println("Человек " + name + " не перепрыгнул через препятствие  высотой: " + height);
            isStopped = true;
            return false;
        }
    }

    @Override
    public boolean run(int length) {
        if (length <= maxRun) {
            System.out.println("Человек " + name + " пробежал расстояние длиной: " + length);
            return true;
        } else {
            System.out.println("человек " + name + " не пробежал расстояние длиной: " + length);
            isStopped = true;
            return false;
        }
    }

    @Override
    public boolean isStopped() {
        return isStopped;
    }
}
