package Game;

public interface Obstacle {

}
