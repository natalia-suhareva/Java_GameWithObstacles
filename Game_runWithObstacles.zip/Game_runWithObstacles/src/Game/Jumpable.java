package Game;

public interface Jumpable extends Participant {
    boolean jump(int height);
}
