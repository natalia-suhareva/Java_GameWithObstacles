package Game;

public class Treadmill implements Obstacle {
    public int length;

    public Treadmill(int length) {
        this.length = length;
    }

    public void accept(Runnable runnable) {
        runnable.run(length);
    }

}
