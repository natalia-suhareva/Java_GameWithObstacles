package Game;

public interface Participant {
    boolean isStopped();
}
